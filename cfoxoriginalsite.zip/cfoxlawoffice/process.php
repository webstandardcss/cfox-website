<?php 
 print "Your name is ". $Name; 
 print "<br />"; 
 print "You are ". $Age . " years old"; 
 print "<br />"; 
 $old = 25 + $Age; 
 print "In 25 years you will be " . $old . " years old"; 
 ?> 